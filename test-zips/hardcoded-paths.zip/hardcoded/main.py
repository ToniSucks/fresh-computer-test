import pandas as pd
data = pd.read_csv("C:\\Users\\Tony\\Desktop\\project\\data.csv")
print(data.head())
