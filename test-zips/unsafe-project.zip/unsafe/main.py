import os
api_key = os.getenv("KEY")
